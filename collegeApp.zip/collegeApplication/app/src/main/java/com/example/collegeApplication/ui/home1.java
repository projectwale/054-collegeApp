package com.example.collegeApplication.ui;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.os.StrictMode;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.collegeApplication.R;
import com.example.collegeApplication.UrlLinks;
import com.example.collegeApplication.jSOnClassforData;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class home1 extends Fragment {
    TextView reg;
    Spinner spin1;
    TextInputLayout ti1,ti2,ti3,ti4;
    EditText ed1,ed2,ed3,ed4;
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_home1, container, false);

        reg = root.findViewById(R.id.txreg);
        ti1 = root.findViewById(R.id.usename);
        ed1 = ti1.getEditText();
        ti2 = root.findViewById(R.id.email);
        ed2 = ti2.getEditText();
        ti3 = root.findViewById(R.id.mobile);
        ed3 = ti3.getEditText();
        ti4 = root.findViewById(R.id.password);
        ed4 = ti4.getEditText();
        spin1 = root.findViewById(R.id.deptname);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getActivity(), R.layout.dropdown_item, getResources().getStringArray(R.array.deptname));
        spin1.setAdapter(adapter2);

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = ed1.getText().toString();
                String email = ed2.getText().toString();
                String mobile = ed3.getText().toString();
                String password = ed4.getText().toString();
                String dept = spin1.getSelectedItem().toString();
                Pattern pattern = Patterns.EMAIL_ADDRESS;

                if(username.equals("") || email.equals("")|| mobile.equals("")|| password.equals("") || dept.equals("Select department")){
                    Snackbar.make(v, "Please fill details", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(!pattern.matcher(email).matches()){
                    Snackbar.make(v, "Please enter valid email", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(mobile.length() != 10){
                    Snackbar.make(v, "Please enter valid mobile number", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.addTPOData;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(4);

                    nameValuePairs.add(new BasicNameValuePair("username", username));
                    nameValuePairs.add(new BasicNameValuePair("password", password));
                    nameValuePairs.add(new BasicNameValuePair("emailid", email));
                    nameValuePairs.add(new BasicNameValuePair("mobilenumber", mobile));
                    nameValuePairs.add(new BasicNameValuePair("dept", dept));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {
                        ed1.setText("");
                        ed2.setText("");
                        ed3.setText("");
                        ed4.setText("");
                        spin1.setSelection(0);
                        Snackbar.make(v, "TPO Added successfully!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    } else {
                        Snackbar.make(v, "Something went wrong!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                }

            }
        });

        return root;
    }

}