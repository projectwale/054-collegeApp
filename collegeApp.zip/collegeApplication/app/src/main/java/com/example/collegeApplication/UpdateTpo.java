package com.example.collegeApplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;

import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class UpdateTpo extends AppCompatActivity {

    TextView reg;
    Spinner spin1;
    TextInputLayout ti1,ti2,ti3,ti4;
    EditText ed1,ed2,ed3,ed4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_tpo);

        // Enable the back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

            // Set the title with white color
            SpannableString spannableString = new SpannableString("Update TPO");
            int whiteColor = ContextCompat.getColor(this, android.R.color.white);
            spannableString.setSpan(new ForegroundColorSpan(whiteColor), 0, spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            getSupportActionBar().setTitle(spannableString);

            // Set the color of the back button icon to white
            Drawable upArrow = ContextCompat.getDrawable(this, R.drawable.back); // Replace with your own back icon
            if (upArrow != null) {
                upArrow.setColorFilter(whiteColor, PorterDuff.Mode.SRC_ATOP);
                getSupportActionBar().setHomeAsUpIndicator(upArrow);
            }
        }

        reg = findViewById(R.id.txreg);
        ti1 = findViewById(R.id.usename);
        ed1 = ti1.getEditText();
        ti2 = findViewById(R.id.email);
        ed2 = ti2.getEditText();
        ti3 = findViewById(R.id.mobile);
        ed3 = ti3.getEditText();
        ti4 = findViewById(R.id.password);
        ed4 = ti4.getEditText();
        spin1 = findViewById(R.id.deptname);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(UpdateTpo.this, R.layout.dropdown_item, getResources().getStringArray(R.array.deptname));
        spin1.setAdapter(adapter2);

        ed1.setText(getIntent().getStringExtra("username"));
        ed2.setText(getIntent().getStringExtra("email"));
        ed3.setText(getIntent().getStringExtra("mobile"));
        ed4.setText(getIntent().getStringExtra("password"));
        String searchText = getIntent().getStringExtra("dept");
        int index = -1;

        for (int i = 0; i < adapter2.getCount(); i++) {
            if (adapter2.getItem(i).equals(searchText)) {
                index = i;
                break;
            }
        }

        if (index != -1) {
            spin1.setSelection(index);
        } else {
            spin1.setSelection(0);
        }

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = ed1.getText().toString();
                String email = ed2.getText().toString();
                String mobile = ed3.getText().toString();
                String password = ed4.getText().toString();
                String dept = spin1.getSelectedItem().toString();
                Pattern pattern = Patterns.EMAIL_ADDRESS;

                if(username.equals("") || email.equals("")|| mobile.equals("")|| password.equals("") || dept.equals("Select department")){
                    Snackbar.make(v, "Please fill details", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(!pattern.matcher(email).matches()){
                    Snackbar.make(v, "Please enter valid email", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(mobile.length() != 10){
                    Snackbar.make(v, "Please enter valid mobile number", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.editTPOData;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(6);

                    nameValuePairs.add(new BasicNameValuePair("id", getIntent().getStringExtra("id")));
                    nameValuePairs.add(new BasicNameValuePair("username", username));
                    nameValuePairs.add(new BasicNameValuePair("password", password));
                    nameValuePairs.add(new BasicNameValuePair("emailid", email));
                    nameValuePairs.add(new BasicNameValuePair("mobilenumber", mobile));
                    nameValuePairs.add(new BasicNameValuePair("dept", dept));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {
                        Snackbar.make(v, "TPO updated successfully!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    } else {
                        Snackbar.make(v, "Something went wrong!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                }

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}