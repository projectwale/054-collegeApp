package com.example.collegeApplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Pattern;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class register extends AppCompatActivity {
    private static final int PICK_PDF_REQUEST = 1;
    private Uri file_path_10;
    private Uri file_path_12;
    private Uri file_path_dip;
    Spinner spin1,spin2,spin3,spin4,spin5,spin6;
    private Calendar calendar;
    TextView reg;
    TextInputLayout name,rollno,prnno,dob,email,mobileno,qualification,marks10,marks12,diploma,lastsem,skill,language,project,intenship,gapyear,firsttear,secondyear,thirdyear;
    EditText ed1,ed2,ed3,ed4,ed5,ed6,ed7,ed8,ed9,ed10,ed11,ed12,ed13,ed14,ed15,ed16,ed17,ed18,ed19;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        calendar = Calendar.getInstance();

        reg = findViewById(R.id.txreg);

        name = findViewById(R.id.name);
        ed1 = name.getEditText();
        rollno = findViewById(R.id.rollno);
        ed2 = rollno.getEditText();
        prnno = findViewById(R.id.prnno);
        ed3 = prnno.getEditText();
        dob = findViewById(R.id.dob);
        ed4 = dob.getEditText();
        email = findViewById(R.id.email);
        ed5 = email.getEditText();
        mobileno = findViewById(R.id.mobileno);
        ed6 = mobileno.getEditText();
        spin1 = findViewById(R.id.gender);
        spin2 = findViewById(R.id.deptname);
        qualification = findViewById(R.id.qualification);
        ed7 = qualification.getEditText();
        spin3 = findViewById(R.id.passingyear);
        marks10 = findViewById(R.id.marks10);
        ed8 = marks10.getEditText();
        marks12 = findViewById(R.id.marks12);
        ed9 = marks12.getEditText();
        spin4 = findViewById(R.id.selectdiploma);
        diploma = findViewById(R.id.diploma);
        ed10 = diploma.getEditText();
        lastsem = findViewById(R.id.lastsem);
        ed11 = lastsem.getEditText();
        skill = findViewById(R.id.skill);
        ed12 = skill.getEditText();
        language = findViewById(R.id.language);
        ed13 = language.getEditText();
        project = findViewById(R.id.project);
        ed14 = project.getEditText();
        spin5 = findViewById(R.id.selectintenship);
        intenship = findViewById(R.id.intenship);
        ed15 = intenship.getEditText();
        spin6 = findViewById(R.id.selectgapyear);
        gapyear = findViewById(R.id.gapyear);
        ed16 = gapyear.getEditText();
        firsttear = findViewById(R.id.firsttear);
        ed17 = firsttear.getEditText();
        secondyear = findViewById(R.id.secondyear);
        ed18 = secondyear.getEditText();
        thirdyear = findViewById(R.id.thirdyear);
        ed19 = thirdyear.getEditText();

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(register.this, R.layout.dropdown_item, getResources().getStringArray(R.array.gender));
        spin1.setAdapter(adapter1);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(register.this, R.layout.dropdown_item, getResources().getStringArray(R.array.deptname));
        spin2.setAdapter(adapter2);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<>(register.this, R.layout.dropdown_item, getResources().getStringArray(R.array.passingyear));
        spin3.setAdapter(adapter3);
        ArrayAdapter<String> adapter4 = new ArrayAdapter<>(register.this, R.layout.dropdown_item,  getResources().getStringArray(R.array.yesno));
        spin4.setAdapter(adapter4);
        spin5.setAdapter(adapter4);
        spin6.setAdapter(adapter4);

        diploma.setVisibility(View.GONE);
        intenship.setVisibility(View.GONE);
        gapyear.setVisibility(View.GONE);

        ed4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(register.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                ed4.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                            }
                        }, year, month, dayOfMonth);

                datePickerDialog.show();
            }
        });

        spin4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedItem = (String) parentView.getItemAtPosition(position);
                if(selectedItem.equals("No")){
                    ed10.setText("");
                    file_path_dip = null;
                    diploma.setVisibility(View.GONE);
                }
                else{
                    diploma.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });
        spin5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedItem = (String) parentView.getItemAtPosition(position);
                if(selectedItem.equals("No")){
                    ed15.setText("");
                    intenship.setVisibility(View.GONE);
                }
                else{
                    intenship.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });
        spin6.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedItem = (String) parentView.getItemAtPosition(position);
                if(selectedItem.equals("No")){
                    ed16.setText("");
                    gapyear.setVisibility(View.GONE);
                }
                else{
                    gapyear.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
            }
        });

        ed8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filePickerForEditText(ed8);
            }
        });

        ed9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filePickerForEditText(ed9);
            }
        });

        ed10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                filePickerForEditText(ed10);
            }
        });

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = ed1.getText().toString();
                String rollno = ed2.getText().toString();
                String prnno = ed3.getText().toString();
                String dob = ed4.getText().toString();
                String email = ed5.getText().toString();
                String mobile = ed6.getText().toString();
                String qualification = ed7.getText().toString();
                String marks10 = ed8.getText().toString();
                String marks12 = ed9.getText().toString();
                String diploma = ed10.getText().toString();
                String lastsem = ed11.getText().toString();
                String skill = ed12.getText().toString();
                String language = ed13.getText().toString();
                String project = ed14.getText().toString();
                String intenship = ed15.getText().toString();
                String gap = ed16.getText().toString();
                String year1st = ed17.getText().toString();
                String year2nd = ed18.getText().toString();
                String year3rd = ed19.getText().toString();

                String gender = spin1.getSelectedItem().toString();
                String dept = spin2.getSelectedItem().toString();
                String passingyear = spin3.getSelectedItem().toString();
                String selectdiploma = spin4.getSelectedItem().toString();
                String selectintenship = spin5.getSelectedItem().toString();
                String selectgapyear = spin6.getSelectedItem().toString();

                Pattern pattern = Patterns.EMAIL_ADDRESS;
                if(name.equals("") || rollno.equals("") || prnno.equals("") ||
                        dob.equals("") || email.equals("") || mobile.equals("")||
                        qualification.equals("") || marks10.equals("") || marks12.equals("")||
                        lastsem.equals("") || skill.equals("") || language.equals("")||
                        project.equals("") || year1st.equals("") || year2nd.equals("")||
                        year3rd.equals("") || gender.equals("Select gender") || dept.equals("Select department")||
                        passingyear.equals("Select passing year")){

                    Snackbar.make(v, "Please fill details.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(prnno.length() != 8){
                    Snackbar.make(v, "Please enter valid PRN number", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(!pattern.matcher(email).matches()){
                    Snackbar.make(v, "Please enter valid email", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(mobile.length() != 10){
                    Snackbar.make(v, "Please enter valid mobile number", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(selectdiploma.equals("Yes") && diploma.equals("")){
                    Snackbar.make(v, "Please select diploma certificate!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(selectintenship.equals("Yes") && intenship.equals("")){
                    Snackbar.make(v, "Please enter internship details!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(selectgapyear.equals("Yes") && gap.equals("")){
                    Snackbar.make(v, "Please enter gap year!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {

                    StrictMode.ThreadPolicy policy1 = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy1);
                    String url1 = UrlLinks.calledfunction;

                    List<NameValuePair> nameValuePairs1 = new ArrayList<NameValuePair>(1);

                    String result1 = null;
                    try {
                        result1 = jSOnClassforData.forCallingStringAndreturnSTring(url1, nameValuePairs1);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    System.out.println(result1);

                    upLoad2Server(file_path_10,prnno+"&&&"+marks10);
                    upLoad2Server(file_path_12,prnno+"&&&"+marks12);
                    if(selectdiploma.equals("Yes")){
                        upLoad2Server(file_path_dip,prnno+"&&&"+diploma);
                    }
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.pyregister;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(22);

                    nameValuePairs.add(new BasicNameValuePair("name", name));
                    nameValuePairs.add(new BasicNameValuePair("rollno", rollno));
                    nameValuePairs.add(new BasicNameValuePair("prnno", prnno));
                    nameValuePairs.add(new BasicNameValuePair("dob", dob));
                    nameValuePairs.add(new BasicNameValuePair("email", email));
                    nameValuePairs.add(new BasicNameValuePair("mobile", mobile));
                    nameValuePairs.add(new BasicNameValuePair("gender", gender));
                    nameValuePairs.add(new BasicNameValuePair("dept", dept));
                    nameValuePairs.add(new BasicNameValuePair("qualification", qualification));
                    nameValuePairs.add(new BasicNameValuePair("passingyear", passingyear));
                    nameValuePairs.add(new BasicNameValuePair("marks10", marks10));
                    nameValuePairs.add(new BasicNameValuePair("marks12", marks12));
                    if(selectdiploma.equals("Yes")){
                        nameValuePairs.add(new BasicNameValuePair("diploma", diploma));
                    }else{
                        nameValuePairs.add(new BasicNameValuePair("diploma", "No"));
                    }
                    nameValuePairs.add(new BasicNameValuePair("lastsem", lastsem));
                    nameValuePairs.add(new BasicNameValuePair("skill", skill));
                    nameValuePairs.add(new BasicNameValuePair("language", language));
                    nameValuePairs.add(new BasicNameValuePair("project", project));
                    if(selectintenship.equals("Yes")){
                        nameValuePairs.add(new BasicNameValuePair("intenship", intenship));
                    }else{
                        nameValuePairs.add(new BasicNameValuePair("intenship", "No"));
                    }
                    if(selectgapyear.equals("Yes")){
                        nameValuePairs.add(new BasicNameValuePair("gap", gap));
                    }else{
                        nameValuePairs.add(new BasicNameValuePair("gap", "No"));
                    }
                    nameValuePairs.add(new BasicNameValuePair("year1st", year1st));
                    nameValuePairs.add(new BasicNameValuePair("year2nd", year2nd));
                    nameValuePairs.add(new BasicNameValuePair("year3rd", year3rd));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url, nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {
                        Snackbar.make(v, "Successfully register.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                        Intent io = new Intent(register.this, login.class);
                        startActivity(io);
                        finish();
                    } else {
                        Snackbar.make(v, "Something went wrong.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                }
            }
        });

    }

    public static int upLoad2Server(Uri sourceFileUri,String fileName) {

        String upLoadServerUri = UrlLinks.uploadPdf;
        HttpURLConnection conn = null;
        DataOutputStream dos = null;
        DataInputStream inStream = null;
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        int bytesRead, bytesAvailable, bufferSize;
        byte[] buffer;
        int maxBufferSize = 1 * 1024 * 1024;

        Log.e("Huzza", sourceFileUri.toString());
        System.out.println(sourceFileUri);
        File sourceFile = new File(sourceFileUri.toString());
        if (!sourceFile.isFile()) {
            Log.e("Huzza", "Source File Does not exist");
            return 0;
        }
        int serverResponseCode = 0;
        try { // open a URL connection to the Servlet
            FileInputStream fileInputStream = new FileInputStream(sourceFile);
            URL url = new URL(upLoadServerUri);
            conn = (HttpURLConnection) url.openConnection(); // Open a HTTP  connection to  the URL
            conn.setDoInput(true); // Allow Inputs
            conn.setDoOutput(true); // Allow Outputs
            conn.setUseCaches(false); // Don't use a Cached Copy
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Connection", "Keep-Alive");
            conn.setRequestProperty("ENCTYPE", "multipart/form-data");
            conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
            conn.setRequestProperty("uploaded_file", fileName);
            conn.setRequestProperty("uploadername", "uploadername");
            dos = new DataOutputStream(conn.getOutputStream());

            dos.writeBytes(twoHyphens + boundary + lineEnd);
            dos.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\""+ fileName + "\"" + lineEnd);
            dos.writeBytes(lineEnd);

            bytesAvailable = fileInputStream.available(); // create a buffer of  maximum size
            Log.i("Huzza", "Initial .available : " + bytesAvailable);

            bufferSize = Math.min(bytesAvailable, maxBufferSize);
            buffer = new byte[bufferSize];

            // read file and write it into form...
            bytesRead = fileInputStream.read(buffer, 0, bufferSize);

            while (bytesRead > 0) {
                dos.write(buffer, 0, bufferSize);
                bytesAvailable = fileInputStream.available();
                bufferSize = Math.min(bytesAvailable, maxBufferSize);
                bytesRead = fileInputStream.read(buffer, 0, bufferSize);
            }

            // send multipart form data necesssary after file data...
            dos.writeBytes(lineEnd);
            dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

            // Responses from the server (code and message)
            serverResponseCode = conn.getResponseCode();
            String serverResponseMessage = conn.getResponseMessage();

            Log.i("Upload file to server", "HTTP Response is : " + serverResponseMessage + ": " + serverResponseCode);
            // close streams
            Log.i("Upload file to server", fileName + " File is written");
            fileInputStream.close();
            dos.flush();
            dos.close();
        } catch (MalformedURLException ex) {
            ex.printStackTrace();
            Log.e("Upload file to server", "error: " + ex.getMessage(), ex);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            BufferedReader rd = new BufferedReader(new InputStreamReader(conn
                    .getInputStream()));
            String line;
            while ((line = rd.readLine()) != null) {
                Log.i("Huzza", "RES Message: " + line);
            }
            rd.close();
        } catch (IOException ioex) {
            Log.e("Huzza", "error: " + ioex.getMessage(), ioex);
        }
        return serverResponseCode;  // like 200 (Ok)

    }

    private void filePickerForEditText(final EditText editText) {
        Intent intent = new Intent();
        intent.setType("application/pdf");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select PDF"), PICK_PDF_REQUEST);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_PDF_REQUEST && resultCode == RESULT_OK) {
            if (data != null && data.getData() != null) {
                Uri selectedFileUri = data.getData();
                String selectedFileName = getFileNameFromUri(selectedFileUri);

                String prnno = ed3.getText().toString();
                if(!prnno.equals("")){
                    String filePath = saveFileFromUri(selectedFileUri,prnno+"&&&"+selectedFileName);
                    if (ed8.isFocused()) {
                        file_path_10 = Uri.parse(filePath);
                        setFileNameToEditText(selectedFileName, ed8);
                    } else if (ed9.isFocused()) {
                        file_path_12 = Uri.parse(filePath);
                        setFileNameToEditText(selectedFileName, ed9);
                    } else if (ed10.isFocused()) {
                        file_path_dip = Uri.parse(filePath);
                        setFileNameToEditText(selectedFileName, ed10);
                    }
                }
                else{
                    Snackbar.make(findViewById(android.R.id.content), "Please enter PRN No.!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
            }
        }
    }

    private String saveFileFromUri(Uri uri,String filename) {
        String filePath = null;
        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            if (inputStream != null) {
                File tempFile = new File(getFilesDir(), filename);
                FileOutputStream outputStream = new FileOutputStream(tempFile);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = inputStream.read(buffer)) > 0) {
                    outputStream.write(buffer, 0, length);
                }
                outputStream.flush();
                outputStream.close();
                inputStream.close();
                filePath = tempFile.getAbsolutePath();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return filePath;
    }


    @SuppressLint("Range")
    private String getFileNameFromUri(Uri uri) {
        String fileName = null;
        if (uri.getScheme().equals("content")) {
            try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
                if (cursor != null && cursor.moveToFirst()) {
                    fileName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
                }
            }
        }
        if (fileName == null) {
            fileName = uri.getPath();
            int cut = fileName.lastIndexOf('/');
            if (cut != -1) {
                fileName = fileName.substring(cut + 1);
            }
        }
        return fileName;
    }

    private void setFileNameToEditText(String fileName, EditText editText) {
        editText.setText(fileName);
    }

}