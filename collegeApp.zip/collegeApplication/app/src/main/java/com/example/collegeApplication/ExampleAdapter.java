package com.example.collegeApplication;

import static com.example.collegeApplication.login.session;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;


public class ExampleAdapter extends RecyclerView.Adapter<ExampleAdapter.ExampleViewHolder> {
    private List<ExampleItem> exampleList;
    private Context mContext;

    class ExampleViewHolder extends RecyclerView.ViewHolder {
        TextView textView1,textView2,textView3,textView4,textView5,Verify;
        LinearLayout parentLayout,mainLin,dipLin,tenmark,twelvemark;

        ExampleViewHolder(View itemView) {
            super(itemView);

            this.textView1 = (TextView) itemView.findViewById(R.id.textview1);
            this.textView2 = (TextView) itemView.findViewById(R.id.textview2);
            this.textView3 = (TextView) itemView.findViewById(R.id.textview3);
            this.textView4 = (TextView) itemView.findViewById(R.id.textview4);
            this.textView5 = (TextView) itemView.findViewById(R.id.textview5);
            this.Verify = (TextView) itemView.findViewById(R.id.verify);
            this.parentLayout = (LinearLayout) itemView.findViewById(R.id.lin);
            this.mainLin = (LinearLayout) itemView.findViewById(R.id.lin2);
            this.dipLin = (LinearLayout) itemView.findViewById(R.id.downdip);
            this.tenmark = (LinearLayout) itemView.findViewById(R.id.down10);
            this.twelvemark = (LinearLayout) itemView.findViewById(R.id.down12);

        }
    }

    public ExampleAdapter(List<ExampleItem> exampleList2, Context context) {
        this.exampleList = exampleList2;
    }

    public ExampleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       // mContext = parent.getContext();
        return new ExampleViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_apps, parent, false));
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        this.mContext = recyclerView.getContext();
    }
    
    public void onBindViewHolder(ExampleViewHolder holder, int position) {

        final ExampleItem currentItem = (ExampleItem) this.exampleList.get(position);
        holder.textView1.setText(currentItem.getText1());
        holder.textView2.setText(currentItem.getText3());
        holder.textView3.setText(currentItem.getText4());
        holder.textView4.setText("PRN No. : "+currentItem.getText2());
        holder.textView5.setText("Qualification : "+currentItem.getText5());

        if(currentItem.getText6().equals("-")){
            if(currentItem.getText9().equals("Unblock")){
                holder.Verify.setText("Block");
            }
            else {
                holder.Verify.setText("Unblock");
            }
        }
        else {
            holder.Verify.setText("Verify");
            holder.mainLin.setVisibility(View.VISIBLE);
            if(!currentItem.getText8().equals("No")){
                holder.dipLin.setVisibility(View.VISIBLE);
            }
        }

        holder.tenmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                downloadPdf(mContext, UrlLinks.urlserverpython+currentItem.getText6(), "10th-marksheet.pdf");
            }
        });

        holder.twelvemark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                downloadPdf(mContext, UrlLinks.urlserverpython+currentItem.getText7(), "12th-marksheet.pdf");
            }
        });

        holder.dipLin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                downloadPdf(mContext, UrlLinks.urlserverpython+currentItem.getText8(), "diploma-marksheet.pdf");
            }
        });

        holder.Verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String buttonText = ((TextView) view).getText().toString();

                if(buttonText.equals("Verify")){
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.verifyUser;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(3);

                    nameValuePairs.add(new BasicNameValuePair("prnno", currentItem.getText2()));
                    nameValuePairs.add(new BasicNameValuePair("email", currentItem.getText3()));
                    nameValuePairs.add(new BasicNameValuePair("name", currentItem.getText1()));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {
                        Snackbar.make(view, "User verified successfully.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    } else {
                        Snackbar.make(view, "Something went wrong.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                }
                else {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.changeBlockStatus;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(3);

                    nameValuePairs.add(new BasicNameValuePair("prnno", currentItem.getText2()));
                    nameValuePairs.add(new BasicNameValuePair("email", currentItem.getText3()));
                    nameValuePairs.add(new BasicNameValuePair("buttonText", buttonText));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {
                        Snackbar.make(view, "User "+buttonText, Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    } else {
                        Snackbar.make(view, "Something went wrong.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                }
            }
        });
    }

    public static void downloadPdf(Context context, String downloadUrl, String fileName) {
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
        request.setTitle("Downloading PDF");
        request.setDescription("Downloading " + fileName);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

        DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        if (downloadManager != null) {
            downloadManager.enqueue(request);
        }
    }

    public int getItemCount() {
        return this.exampleList.size();
    }

    /* access modifiers changed from: 0000 */
    public void setFilter(List<ExampleItem> filterdNames) {
        this.exampleList = filterdNames;
        notifyDataSetChanged();
    }
}