package com.example.collegeApplication.ui.ViewParticipantes;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.example.collegeApplication.MainActivity;
import com.example.collegeApplication.R;
import com.example.collegeApplication.UrlLinks;
import com.example.collegeApplication.jSOnClassforData;
import com.example.collegeApplication.login;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class viewParticipantes extends Fragment {
    TextInputLayout marks, salary;
    EditText edmarks, edsalary;
    JSONArray originalData;
    TableLayout tableLayout;
    TextView txreg;

    @SuppressLint("ResourceAsColor")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_view_participantes, container, false);

        tableLayout = root.findViewById(R.id.table_layout);

        // Load table data
        loadData();

        marks = root.findViewById(R.id.marks);
        edmarks = marks.getEditText();
        salary = root.findViewById(R.id.salary);
        edsalary = salary.getEditText();
        txreg = root.findViewById(R.id.log);

        edmarks.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterData();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        edsalary.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterData();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        txreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<HashMap<String, String>> tableData = getDataFromTable();
                int numRows = tableData.size();
                System.out.println("Number of rows in the table: " + numRows);
                if(numRows > 0){
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.downloadData;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);

                    JSONArray jsonArray = new JSONArray();
                    for (HashMap<String, String> map : tableData) {
                        JSONObject jsonObject = new JSONObject(map);
                        jsonArray.put(jsonObject);
                    }
                    nameValuePairs.add(new BasicNameValuePair("data", jsonArray.toString()));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {
                        downloadPdf(getActivity(), UrlLinks.urlserverpython+"static/output.pdf", "data.pdf");
                    }
                    else {
                        Snackbar.make(view, "File not download.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                }
                else{
                    Snackbar.make(view, "Please fill details.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
            }
        });

        return root;
    }
    public static void downloadPdf(Context context, String downloadUrl, String fileName) {
        DownloadManager.Request request = new DownloadManager.Request(Uri.parse(downloadUrl));
        request.setTitle("Downloading PDF");
        request.setDescription("Downloading " + fileName);
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);

        DownloadManager downloadManager = (DownloadManager) context.getSystemService(Context.DOWNLOAD_SERVICE);
        if (downloadManager != null) {
            downloadManager.enqueue(request);
        }
    }

    private ArrayList<HashMap<String, String>> getDataFromTable() {
        HashMap<String, String> rowDataMap;
        ArrayList<HashMap<String, String>> tableDataList = new ArrayList<>();

        int childCount = tableLayout.getChildCount();
        for (int i = 1; i < childCount; i++) {
            View view = tableLayout.getChildAt(i);
            if (view instanceof TableRow) {
                TableRow row = (TableRow) view;
                rowDataMap = new HashMap<>();
                for (int j = 0; j < row.getChildCount(); j++) {
                    View childView = row.getChildAt(j);
                    if (childView instanceof TextView) {
                        TextView textView = (TextView) childView;
                        String header = getHeaderAt(j); // Get the header corresponding to the column index
                        String data = textView.getText().toString();
                        rowDataMap.put(header, data);
                    }
                }
                tableDataList.add(rowDataMap);
            }
        }

        return tableDataList;
    }

    private String getHeaderAt(int columnIndex) {
        String[] headers = {"Full name", "PRN No.", "Email", "Mobile", "Department", "Qualification", "Last year marks", "Company name", "Company location", "Designation", "Salary package(in Laks)"};
        if (columnIndex >= 0 && columnIndex < headers.length) {
            return headers[columnIndex];
        }
        return ""; // Return empty string if index is out of bounds
    }

    private void loadData() {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        String url = UrlLinks.getEnrolledData;
        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);

        String result = null;
        try {
            result = jSOnClassforData.forCallingStringAndreturnSTring(url, nameValuePairs);
            originalData = new JSONArray(result);
            populateTable(originalData);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void populateTable(JSONArray jsonArray) throws JSONException {
        TableRow headerRow = new TableRow(getActivity());
        String[] headers = {"Full name", "PRN No.", "Email", "Mobile", "Department", "Qualification", "Last year marks", "Company name", "Company location", "Designation", "Salary package(in Laks)"};

        for (String header : headers) {
            TextView textView = new TextView(getActivity());
            textView.setText(header);
            textView.setPadding(50, 50, 50, 50);
            textView.setTextColor(Color.BLACK);
            textView.setTextSize(22);
            textView.setTypeface(null, Typeface.BOLD);
            headerRow.addView(textView);
        }

        tableLayout.addView(headerRow);

        for (int i = 0; i < jsonArray.length(); i++) {
            JSONArray rowData = jsonArray.getJSONArray(i);
            addRowToTable(rowData);
        }
    }

    private void addRowToTable(JSONArray rowData) throws JSONException {
        TableRow row = new TableRow(getActivity());
        System.out.println();
        System.out.println(rowData);
        for (int j = 0; j < rowData.length(); j++) {
            TextView data11 = new TextView(getActivity());
            data11.setText(String.valueOf(rowData.getString(j)));
            data11.setPadding(50, 35, 50, 35);
            data11.setTextColor(Color.BLACK);
            data11.setTextSize(20);
            row.addView(data11);
        }
        tableLayout.addView(row);
    }

    private void filterData() {
        String marksFilter = edmarks.getText().toString().trim();
        String salaryFilter = edsalary.getText().toString().trim();

        tableLayout.removeViews(1, tableLayout.getChildCount() - 1);

        for (int i = 0; i < originalData.length(); i++) {
            try {
                JSONArray rowData = originalData.getJSONArray(i);

                if ((!TextUtils.isEmpty(marksFilter) && Integer.parseInt(rowData.getString(6))<Integer.parseInt(marksFilter))
                || (!TextUtils.isEmpty(salaryFilter) && Integer.parseInt(rowData.getString(10))<Integer.parseInt(salaryFilter))) {
                    continue;
                }

                addRowToTable(rowData);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}
