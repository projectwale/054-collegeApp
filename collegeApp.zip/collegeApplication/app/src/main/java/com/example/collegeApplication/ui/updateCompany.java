package com.example.collegeApplication.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.StrictMode;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.collegeApplication.R;
import com.example.collegeApplication.UrlLinks;
import com.example.collegeApplication.jSOnClassforData;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class updateCompany extends AppCompatActivity {

    TextView reg;
    Spinner spin1;
    TextInputLayout ti1,ti2,ti3,ti4,ti5,ti6;
    EditText ed1,ed2,ed3,ed4,ed5,ed6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_company);

        // Enable the back button
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);

            // Set the title with white color
            SpannableString spannableString = new SpannableString("Update Campany");
            int whiteColor = ContextCompat.getColor(this, android.R.color.white);
            spannableString.setSpan(new ForegroundColorSpan(whiteColor), 0, spannableString.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            getSupportActionBar().setTitle(spannableString);

            // Set the color of the back button icon to white
            Drawable upArrow = ContextCompat.getDrawable(this, R.drawable.back); // Replace with your own back icon
            if (upArrow != null) {
                upArrow.setColorFilter(whiteColor, PorterDuff.Mode.SRC_ATOP);
                getSupportActionBar().setHomeAsUpIndicator(upArrow);
            }
        }

        reg = findViewById(R.id.txreg);
        ti1 = findViewById(R.id.cid);
        ed1 = ti1.getEditText();
        ti2 = findViewById(R.id.cname);
        ed2 = ti2.getEditText();
        ti3 = findViewById(R.id.cbasic);
        ed3 = ti3.getEditText();
        ti4 = findViewById(R.id.clocation);
        ed4 = ti4.getEditText();
        ti5 = findViewById(R.id.cpackage);
        ed5 = ti5.getEditText();
        ti6 = findViewById(R.id.cskills);
        ed6 = ti6.getEditText();
        spin1 = findViewById(R.id.cposition);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(updateCompany.this, R.layout.dropdown_item, getResources().getStringArray(R.array.working_designations));
        spin1.setAdapter(adapter2);

        ed1.setText(getIntent().getStringExtra("cid"));
        ed2.setText(getIntent().getStringExtra("cname"));
        ed3.setText(getIntent().getStringExtra("cbasic"));
        ed4.setText(getIntent().getStringExtra("clocation"));
        ed5.setText(getIntent().getStringExtra("cpack"));
        ed6.setText(getIntent().getStringExtra("cskill"));
        String searchText = getIntent().getStringExtra("cdesignation");
        int index = -1;

        for (int i = 0; i < adapter2.getCount(); i++) {
            if (adapter2.getItem(i).equals(searchText)) {
                index = i;
                break;
            }
        }

        if (index != -1) {
            spin1.setSelection(index);
        } else {
            spin1.setSelection(0);
        }

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String cid = ed1.getText().toString();
                String cname = ed2.getText().toString();
                String cbasic = ed3.getText().toString();
                String clocation = ed4.getText().toString();
                String cpack = ed5.getText().toString();
                String cskill = ed6.getText().toString();
                String desi = spin1.getSelectedItem().toString();

                if(cid.equals("") || cname.equals("") || cbasic.equals("") || clocation.equals("") || cpack.equals("")|| cskill.equals("") || desi.equals("Select position")){
                    Snackbar.make(v, "Please fill details", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(cpack.length() > 2){
                    Snackbar.make(v, "Please enter valid package", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.editCompanyData;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(8);

                    nameValuePairs.add(new BasicNameValuePair("id", getIntent().getStringExtra("id")));
                    nameValuePairs.add(new BasicNameValuePair("cid", cid));
                    nameValuePairs.add(new BasicNameValuePair("cname", cname));
                    nameValuePairs.add(new BasicNameValuePair("cbasic", cbasic));
                    nameValuePairs.add(new BasicNameValuePair("clocation", clocation));
                    nameValuePairs.add(new BasicNameValuePair("cdesignation", desi));
                    nameValuePairs.add(new BasicNameValuePair("cpack", cpack));
                    nameValuePairs.add(new BasicNameValuePair("cskill", cskill));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {
                        Snackbar.make(v, "Company updated successfully!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    } else {
                        Snackbar.make(v, "Something went wrong!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                }

            }
        });
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}