package com.example.collegeApplication;

public class UrlLinks {
    public static String urlserver="";

    public static String urlserverpython="http://192.168.0.102:5000/";
    public static String registrationurl=urlserver+"registerUser";

    public static String uploadPdf=urlserverpython+"uploadPdf";
    public static String pyregister=urlserverpython+"userRegister";
    public static String getAllusers=urlserverpython+"getAllusers";
    public static String getAllusers1=urlserverpython+"getAllusers1";
    public static String verifyUser=urlserverpython+"verifyUser";
    public static String addTPOData=urlserverpython+"addTPOData";
    public static String getAllTPOs=urlserverpython+"getAllTPOs";
    public static String editTPOData=urlserverpython+"editTPOData";
    public static String deleteTPOData=urlserverpython+"deleteTPOData";
    public static String changeBlockStatus=urlserverpython+"changeBlockStatus";
    public static String addCompany=urlserverpython+"addCompany";
    public static String getAllCompanies=urlserverpython+"getAllCompanies";
    public static String getTpoProfile=urlserverpython+"getTpoProfile";
    public static String getStudProfile=urlserverpython+"getStudProfile";
    public static String updateStudProfile=urlserverpython+"updateStudProfile";
    public static String editCompanyData=urlserverpython+"editCompanyData";
    public static String deleteCompanyData=urlserverpython+"deleteCompanyData";
    public static String pylogin=urlserverpython+"userLogin";
    public static String downloadData=urlserverpython+"downloadData";
    public static String tpologin=urlserverpython+"tpologin";
    public static String applyCompany=urlserverpython+"applyCompany";





    public static String getVideo=urlserverpython+"getVideo";
    public static String uploadimg1=urlserverpython+"uploadimg1";
    public static String calledfunction=urlserverpython+"calledfunction";
    public static String uploadimgandvideo=urlserverpython+"uploadimgandvideo";

    public static String viewCultureScedule=urlserverpython+"viewScedule";
    public static String viewCultureImgVid=urlserverpython+"viewCultureImgVid";
    public static String viewCultureNotice=urlserverpython+"viewCultureNotice";
    public static String Enroll=urlserverpython+"Enroll";

    public static String getEnrolledData=urlserverpython+"getEnrolledData";
    public static String deleteData=urlserverpython+"deleteData";

}
