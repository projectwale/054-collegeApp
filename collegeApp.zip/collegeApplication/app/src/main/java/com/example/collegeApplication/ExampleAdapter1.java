package com.example.collegeApplication;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.collegeApplication.ui.updateCompany;
import com.google.android.material.snackbar.Snackbar;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


public class ExampleAdapter1 extends RecyclerView.Adapter<ExampleAdapter1.ExampleViewHolder> {
    private List<ExampleItem1> exampleList;
    private List<ExampleItem1> exampleListFull;
    private Context mContext;

    class ExampleViewHolder extends RecyclerView.ViewHolder {
        TextView textView1, textView2, textView3,edit,delete;
        RelativeLayout parentLayout;

        ExampleViewHolder(View itemView) {
            super(itemView);

            this.textView1 = (TextView) itemView.findViewById(R.id.textview1);
            this.textView2 = (TextView) itemView.findViewById(R.id.textview2);
            this.textView3 = (TextView) itemView.findViewById(R.id.textview3);
            this.edit = (TextView) itemView.findViewById(R.id.edit);
            this.delete = (TextView) itemView.findViewById(R.id.delete);
            this.parentLayout = (RelativeLayout) itemView.findViewById(R.id.container);

        }
    }

    public ExampleAdapter1(List<ExampleItem1> exampleList2, Context context) {
       // this.mContext = context;
        this.exampleList = exampleList2;
        this.exampleListFull = new ArrayList(exampleList2);
    }

    public ExampleViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       // mContext = parent.getContext();
        return new ExampleViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_my_apps1, parent, false));
    }
    @Override
    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        this.mContext = recyclerView.getContext();
    }
    
    public void onBindViewHolder(ExampleViewHolder holder, int position) {

        final ExampleItem1 currentItem = (ExampleItem1) this.exampleList.get(position);
        holder.textView1.setText(currentItem.getText3());
        holder.textView2.setText("Location : "+currentItem.getText5());
        holder.textView3.setText("Skills : "+currentItem.getText8());

        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(mContext, updateCompany.class);
                intent.putExtra("id", currentItem.getText1());
                intent.putExtra("cid", currentItem.getText2());
                intent.putExtra("cname", currentItem.getText3());
                intent.putExtra("cbasic", currentItem.getText4());
                intent.putExtra("clocation", currentItem.getText5());
                intent.putExtra("cdesignation", currentItem.getText6());
                intent.putExtra("cpack", currentItem.getText7());
                intent.putExtra("cskill", currentItem.getText8());
                mContext.startActivity(intent);
            }
        });

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                StrictMode.setThreadPolicy(policy);
                String url = UrlLinks.deleteCompanyData;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);

                nameValuePairs.add(new BasicNameValuePair("id", currentItem.getText1()));
                nameValuePairs.add(new BasicNameValuePair("cname", currentItem.getText3()));

                String result = null;
                try {
                    result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (result.equals("success")) {
                    Snackbar.make(view, "Company deleted successfully.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                } else {
                    Snackbar.make(view, "Something went wrong.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
            }
        });
    }

    public int getItemCount() {
        return this.exampleList.size();
    }

    /* access modifiers changed from: 0000 */
    public void setFilter(List<ExampleItem1> filterdNames) {
        this.exampleList = filterdNames;
        notifyDataSetChanged();
    }
}