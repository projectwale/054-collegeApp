package com.example.collegeApplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class deptTpoLogin extends AppCompatActivity {
    TextView login;
    TextInputLayout ti1,ti2;
    EditText ed1,ed2;
    Spinner spin1;
    public static String tpo_session = "";
    public static String tpo_dept_session = "";
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_depttpologin);

        login = findViewById(R.id.log);
        ti1 = findViewById(R.id.username1);
        ed1 = ti1.getEditText();
        ti2 = findViewById(R.id.password1);
        ed2 = ti2.getEditText();
        spin1 = findViewById(R.id.deptname);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(deptTpoLogin.this, R.layout.dropdown_item, getResources().getStringArray(R.array.deptname));
        spin1.setAdapter(adapter2);

        spin1.setSelection(2);;

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = ed1.getText().toString();
                String password = ed2.getText().toString();
                String dept = spin1.getSelectedItem().toString();

                if(username.equals("") || password.equals("") || dept.equals("Select department")){
                    Snackbar.make(v, "Please fill details.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.tpologin;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(3);

                    nameValuePairs.add(new BasicNameValuePair("username", username));
                    nameValuePairs.add(new BasicNameValuePair("password", password));
                    nameValuePairs.add(new BasicNameValuePair("dept", dept));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url, nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {
                        tpo_session = username;
                        tpo_dept_session = dept;
                        Snackbar.make(v, "Successfully", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                        Intent io = new Intent(deptTpoLogin.this, MainActivity2.class);
                        startActivity(io);
                        finish();

                    } else {
                        Snackbar.make(v, "Wrong username or password", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                }
            }
        });
    }
}