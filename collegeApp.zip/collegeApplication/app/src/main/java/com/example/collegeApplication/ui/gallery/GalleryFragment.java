package com.example.collegeApplication.ui.gallery;

import static com.example.collegeApplication.deptTpoLogin.tpo_dept_session;
import static com.example.collegeApplication.deptTpoLogin.tpo_session;
import static com.example.collegeApplication.login.session;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.collegeApplication.MainActivity;
import com.example.collegeApplication.R;
import com.example.collegeApplication.UrlLinks;
import com.example.collegeApplication.databinding.FragmentGalleryBinding;
import com.example.collegeApplication.jSOnClassforData;
import com.example.collegeApplication.login;
import com.example.collegeApplication.register;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.regex.Pattern;

public class GalleryFragment extends Fragment {
    Spinner spin2,spin3;
    String id;
    TextView reg;
    TextInputLayout name,rollno,prnno,email,mobileno,qualification,skill,language,password;
    EditText ed1,ed2,ed3,ed5,ed6,ed7,ed12,ed13,ed14;
    private FragmentGalleryBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        binding = FragmentGalleryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        reg = root.findViewById(R.id.txreg);

        name = root.findViewById(R.id.name);
        ed1 = name.getEditText();
        rollno = root.findViewById(R.id.rollno);
        ed2 = rollno.getEditText();
        prnno = root.findViewById(R.id.prnno);
        ed3 = prnno.getEditText();
        email = root.findViewById(R.id.email);
        ed5 = email.getEditText();
        mobileno = root.findViewById(R.id.mobileno);
        ed6 = mobileno.getEditText();
        spin2 = root.findViewById(R.id.deptname);
        qualification = root.findViewById(R.id.qualification);
        ed7 = qualification.getEditText();
        spin3 = root.findViewById(R.id.passingyear);
        skill = root.findViewById(R.id.skill);
        ed12 = skill.getEditText();
        language = root.findViewById(R.id.language);
        ed13 = language.getEditText();
        password = root.findViewById(R.id.password);
        ed14 = password.getEditText();

        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getActivity(), R.layout.dropdown_item, getResources().getStringArray(R.array.deptname));
        spin2.setAdapter(adapter2);
        ArrayAdapter<String> adapter3 = new ArrayAdapter<>(getActivity(), R.layout.dropdown_item, getResources().getStringArray(R.array.passingyear));
        spin3.setAdapter(adapter3);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        String url = UrlLinks.getStudProfile;
        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);

        nameValuePairs.add(new BasicNameValuePair("username", session));

        String result = null;
        try {
            result = jSOnClassforData.forCallingStringAndreturnSTring(url, nameValuePairs);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        try {
            JSONArray jsonArray = new JSONArray(result);

            id = String.valueOf(jsonArray.getString(0));
            String username = String.valueOf(jsonArray.getString(1));
            String rollno = String.valueOf(jsonArray.getString(2));
            String prnno = String.valueOf(jsonArray.getString(3));
            String email = String.valueOf(jsonArray.getString(5));
            String mobile = String.valueOf(jsonArray.getString(6));
            String dept = String.valueOf(jsonArray.getString(8));
            String qual = String.valueOf(jsonArray.getString(9));
            String pyear = String.valueOf(jsonArray.getString(10));
            String skill = String.valueOf(jsonArray.getString(15));
            String lang = String.valueOf(jsonArray.getString(16));
            String password = String.valueOf(jsonArray.getString(23));

            ed1.setText(username);
            ed2.setText(rollno);
            ed3.setText(prnno);
            ed5.setText(email);
            ed6.setText(mobile);
            ed7.setText(qual);
            ed12.setText(skill);
            ed13.setText(lang);
            ed14.setText(password);

            int index = -1;
            for (int i = 0; i < adapter2.getCount(); i++) {
                if (adapter2.getItem(i).equals(dept)) {
                    index = i;
                    break;
                }
            }
            if (index != -1) {
                spin2.setSelection(index);
            } else {
                spin2.setSelection(0);
            }

            int index1 = -1;
            for (int i = 0; i < adapter3.getCount(); i++) {
                if (adapter3.getItem(i).equals(pyear)) {
                    index1 = i;
                    break;
                }
            }
            if (index1 != -1) {
                spin3.setSelection(index1);
            } else {
                spin3.setSelection(0);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = ed1.getText().toString();
                String rollno = ed2.getText().toString();
                String prnno = ed3.getText().toString();
                String email = ed5.getText().toString();
                String mobile = ed6.getText().toString();
                String qualification = ed7.getText().toString();
                String skill = ed12.getText().toString();
                String language = ed13.getText().toString();
                String password = ed14.getText().toString();

                String dept = spin2.getSelectedItem().toString();
                String passingyear = spin3.getSelectedItem().toString();

                Pattern pattern = Patterns.EMAIL_ADDRESS;
                if(name.equals("") || rollno.equals("") || prnno.equals("") || email.equals("") || mobile.equals("") ||
                        qualification.equals("") || skill.equals("") || language.equals("") || dept.equals("Select department") ||
                        passingyear.equals("Select passing year") || password.equals("")){
                    Snackbar.make(v, "Please fill details.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(prnno.length() != 8){
                    Snackbar.make(v, "Please enter valid PRN number", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(!pattern.matcher(email).matches()){
                    Snackbar.make(v, "Please enter valid email", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(mobile.length() != 10){
                    Snackbar.make(v, "Please enter valid mobile number", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.updateStudProfile;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(12);

                    nameValuePairs.add(new BasicNameValuePair("id", id));
                    nameValuePairs.add(new BasicNameValuePair("name", name));
                    nameValuePairs.add(new BasicNameValuePair("rollno", rollno));
                    nameValuePairs.add(new BasicNameValuePair("prnno", prnno));
                    nameValuePairs.add(new BasicNameValuePair("email", email));
                    nameValuePairs.add(new BasicNameValuePair("mobile", mobile));
                    nameValuePairs.add(new BasicNameValuePair("dept", dept));
                    nameValuePairs.add(new BasicNameValuePair("qualification", qualification));
                    nameValuePairs.add(new BasicNameValuePair("passingyear", passingyear));
                    nameValuePairs.add(new BasicNameValuePair("skill", skill));
                    nameValuePairs.add(new BasicNameValuePair("language", language));
                    nameValuePairs.add(new BasicNameValuePair("password", password));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url, nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {
                        Snackbar.make(v, "Profile updated.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                        Intent io = new Intent(getActivity(), login.class);
                        startActivity(io);
                    } else {
                        Snackbar.make(v, "Something went wrong.", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                }
            }
        });

        return root;
    }
}