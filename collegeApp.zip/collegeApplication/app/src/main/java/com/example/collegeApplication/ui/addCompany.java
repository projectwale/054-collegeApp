package com.example.collegeApplication.ui;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.StrictMode;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.example.collegeApplication.R;
import com.example.collegeApplication.UrlLinks;
import com.example.collegeApplication.jSOnClassforData;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputLayout;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class addCompany extends Fragment {

    TextView reg;
    Spinner spin1;
    TextInputLayout ti1,ti2,ti3,ti4,ti5,ti6;
    EditText ed1,ed2,ed3,ed4,ed5,ed6;
    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_add_company, container, false);
        reg = root.findViewById(R.id.txreg);
        ti1 = root.findViewById(R.id.cid);
        ed1 = ti1.getEditText();
        ti2 = root.findViewById(R.id.cname);
        ed2 = ti2.getEditText();
        ti3 = root.findViewById(R.id.cbasic);
        ed3 = ti3.getEditText();
        ti4 = root.findViewById(R.id.clocation);
        ed4 = ti4.getEditText();
        ti5 = root.findViewById(R.id.cpackage);
        ed5 = ti5.getEditText();
        ti6 = root.findViewById(R.id.cskills);
        ed6 = ti6.getEditText();
        spin1 = root.findViewById(R.id.cposition);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getActivity(), R.layout.dropdown_item, getResources().getStringArray(R.array.working_designations));
        spin1.setAdapter(adapter2);

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String cid = ed1.getText().toString();
                String cname = ed2.getText().toString();
                String cbasic = ed3.getText().toString();
                String clocation = ed4.getText().toString();
                String cpack = ed5.getText().toString();
                String cskill = ed6.getText().toString();
                String desi = spin1.getSelectedItem().toString();

                if(cid.equals("") || cname.equals("") || cbasic.equals("") || clocation.equals("") || cpack.equals("")|| cskill.equals("") || desi.equals("Select position")){
                    Snackbar.make(v, "Please fill details", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else if(cpack.length() > 2){
                    Snackbar.make(v, "Please enter valid package", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                }
                else {

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    String url = UrlLinks.addCompany;

                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(7);

                    nameValuePairs.add(new BasicNameValuePair("cid", cid));
                    nameValuePairs.add(new BasicNameValuePair("cname", cname));
                    nameValuePairs.add(new BasicNameValuePair("cbasic", cbasic));
                    nameValuePairs.add(new BasicNameValuePair("clocation", clocation));
                    nameValuePairs.add(new BasicNameValuePair("cdesignation", desi));
                    nameValuePairs.add(new BasicNameValuePair("cpack", cpack));
                    nameValuePairs.add(new BasicNameValuePair("cskill", cskill));

                    String result = null;
                    try {
                        result = jSOnClassforData.forCallingStringAndreturnSTring(url,nameValuePairs);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    if (result.equals("success")) {
                        ed1.setText("");
                        ed2.setText("");
                        ed3.setText("");
                        ed4.setText("");
                        ed5.setText("");
                        ed6.setText("");
                        spin1.setSelection(0);
                        Snackbar.make(v, "Company Added successfully!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    } else {
                        Snackbar.make(v, "Something went wrong!", Snackbar.LENGTH_LONG).setAction("Action", null).show();
                    }
                }

            }
        });

        return root;
    }

}