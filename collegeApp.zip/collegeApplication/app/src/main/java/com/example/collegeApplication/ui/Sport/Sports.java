package com.example.collegeApplication.ui.Sport;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.collegeApplication.R;

public class Sports extends Fragment {
    TextView tx1,tx2,tx3;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_sports, container, false);

        tx1 = root.findViewById(R.id.scedule);
        tx2 = root.findViewById(R.id.notice);
        tx3 = root.findViewById(R.id.imgdata);


        return root;

    }
}