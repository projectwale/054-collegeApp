from flask import Flask,jsonify
from flask import request
import pymysql
from werkzeug.utils import secure_filename
import os
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
from tabulate import tabulate
import json
from datetime import datetime
import pandas as pd 
import pathlib
import ast

import smtplib 
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText 

app = Flask(__name__)

UPLOAD_FOLDER = 'static/schedule/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

UPLOAD_FOLDER1 = 'static/imgvideo/'
app.config['UPLOAD_FOLDER1'] = UPLOAD_FOLDER1

app.secret_key = 'any random string'

def dbConnection():
    try:
        connection = pymysql.connect(host="localhost", user="root", password="root", database="collegeApp")
        return connection
    except:
        print("Something went wrong in database Connection")

def dbClose():
    try:
        dbConnection().close()
    except:
        print("Something went wrong in Close DB Connection")

con = dbConnection()
cursor = con.cursor()

def sendemailtouser(usermail,ogpass):   
    fromaddr = "pranalibscproject@gmail.com"
    toaddr = usermail
    msg = MIMEMultipart()   
    msg['From'] = fromaddr  
    msg['To'] = toaddr 
    msg['Subject'] = "College App"
    body = ogpass
    msg.attach(MIMEText(body, 'plain'))  
    s = smtplib.SMTP('smtp.gmail.com', 587) 
    s.starttls() 
    s.login(fromaddr, "wkwfgosewcljcpqh") 
    text = msg.as_string() 
    s.sendmail(fromaddr, toaddr, text) 
    s.quit()  

@app.route('/calledfunction', methods=['GET', 'POST'])
def calledfunction():
    if request.method == 'POST':
        print("GET") 
        return "success"
    
@app.route('/uploadPdf', methods=['GET', 'POST'])
def uploadPdf():
    if request.method == 'POST':
        print("GET")        
       
        f2= request.files['uploaded_file']      
        filename_secure = f2.filename
        print(filename_secure)
        parts = filename_secure.split("&&&")
        
        pathlib.Path('static/allDoc/',parts[0]).mkdir(exist_ok=True)
        f2.save('static/allDoc/'+parts[0]+'/'+parts[1])
        
        return "success"
    
@app.route('/userRegister', methods=['GET', 'POST'])
def userRegister():
    if request.method == 'POST':
        print("GET")        

        name = request.form.get("name")
        rollno = request.form.get("rollno")        
        prnno = request.form.get("prnno")
        dob = request.form.get("dob")    
        email = request.form.get("email")
        mobile = request.form.get("mobile")        
        gender = request.form.get("gender")
        dept = request.form.get("dept")     
        qualification = request.form.get("qualification")
        passingyear = request.form.get("passingyear")        
        marks10 = request.form.get("marks10")
        marks12 = request.form.get("marks12")    
        diploma = request.form.get("diploma")
        lastsem = request.form.get("lastsem")        
        skill = request.form.get("skill")
        language = request.form.get("language")    
        project = request.form.get("project")
        intenship = request.form.get("intenship")  
        print(intenship)
        gap = request.form.get("gap")
        year1st = request.form.get("year1st")          
        year2nd = request.form.get("year2nd")
        year3rd = request.form.get("year3rd")    
        print("INPUTS")        
        print("username",name)
        
        marks10 = 'static/allDoc/'+prnno+'/'+marks10
        marks12 = 'static/allDoc/'+prnno+'/'+marks12
        if diploma != "No":            
            diploma = 'static/allDoc/'+prnno+'/'+diploma
        
        cursor.execute('SELECT * FROM register WHERE prnno = %s', (prnno))
        count = cursor.rowcount
        if count > 0:
            return "fail"
        else:  
            sql1 = "INSERT INTO register (username, rollno, prnno, dob, email, mobile, gender, dept, qualification, passingyear, marks10, marks12, diploma, lastsem, skill, language, project, internshipdetails, gap, year1st, year2nd, year3rd, password, status, blockstatus) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s);"
            val1 = (name, rollno, prnno, dob, email, mobile, gender, dept, qualification, passingyear, marks10, marks12, diploma, lastsem, skill, language, project, intenship, gap, year1st, year2nd, year3rd, dob, "Unverified", "Unblock")
            cursor.execute(sql1, val1)
            con.commit()
            return "success"
    
@app.route('/getAllusers', methods=['GET', 'POST'])
def getAllusers():
    if request.method == 'POST':        

        username = request.form.get("username")  
        print("admin_getCall",username)
        
        cursor.execute('SELECT * FROM register')
        row = cursor.fetchall() 
        
        jsonObj = json.dumps(row)   
        
        return jsonObj
    
@app.route('/verifyUser', methods=['GET', 'POST'])
def verifyUser():
    if request.method == 'POST':        

        prnno = request.form.get("prnno")  
        email = request.form.get("email") 
        name = request.form.get("name")
           
        sql1 = "UPDATE register SET status = %s WHERE prnno = %s AND email = %s;"
        val1 = ("Verified",prnno,email)
        cursor.execute(sql1,val1)
        con.commit() 
        
        sendemailtouser(email,"Dear "+name+", Your account is verified by Admin.")
        
        return "success"
    
@app.route('/userLogin', methods=['GET', 'POST'])
def userLogin():
    if request.method == 'POST':
        print("GET")        

        prnno = request.form.get("username")
        passw = request.form.get("password")       
        print("INPUTS")        
        print("username",prnno)
        
        cursor.execute('SELECT * FROM register WHERE prnno = %s AND password = %s', (prnno, passw))
        count = cursor.rowcount
        if count > 0:
            row = cursor.fetchone()
            status = row[24]
            blockstatus = row[25]
            print(status+"     "+blockstatus)
            if status == "Unverified":
                return "Unverified"
            elif blockstatus == "Block":
                return "Block"
            else:
                return "success"
        else:
            return "Fail"
        
@app.route('/addTPOData', methods=['GET', 'POST'])
def addTPOData():
    if request.method == 'POST':
        print("GET")        

        username = request.form.get("username")
        password = request.form.get("password")  
        emailid = request.form.get("emailid")
        mobilenumber = request.form.get("mobilenumber") 
        dept = request.form.get("dept") 
        
        cursor.execute('SELECT * FROM tporegister WHERE username = %s', (username))
        count = cursor.rowcount
        if count > 0:
            return "fail"
        else:  
            sql1 = "INSERT INTO tporegister (username, emailid, mobilenumber, password, dept) VALUES (%s, %s, %s, %s, %s);"
            val1 = (username, emailid, mobilenumber, password, dept)
            cursor.execute(sql1, val1)
            con.commit()
            return "success"
        
@app.route('/getAllTPOs', methods=['GET', 'POST'])
def getAllTPOs():
    if request.method == 'POST':        

        username = request.form.get("username")  
        print("admin_getCall",username)
        
        cursor.execute('SELECT * FROM tporegister')
        row = cursor.fetchall() 
        
        jsonObj = json.dumps(row)      
        
        return jsonObj
    
@app.route('/editTPOData', methods=['GET', 'POST'])
def editTPOData():
    if request.method == 'POST':
        print("GET")        

        userid = request.form.get("id")
        username = request.form.get("username")
        password = request.form.get("password")  
        emailid = request.form.get("emailid")
        mobilenumber = request.form.get("mobilenumber") 
        dept = request.form.get("dept") 
        
        sql1 = "UPDATE tporegister SET username = %s,emailid = %s,mobilenumber = %s,password = %s,dept = %s WHERE id = %s;"
        val1 = (username, emailid, mobilenumber, password, dept,userid)
        cursor.execute(sql1,val1)
        con.commit()    
        
        return "success"
    
@app.route('/deleteTPOData', methods=['GET', 'POST'])
def deleteTPOData():
    if request.method == 'POST':        

        idoftpo = request.form.get("id")  
        mobile = request.form.get("mobile")
           
        sql11 = 'DELETE FROM tporegister WHERE id = %s AND mobilenumber = %s;'
        val11 = (idoftpo,mobile)
        cursor.execute(sql11,val11)
        con.commit()  
        
        return "success"
    
@app.route('/changeBlockStatus', methods=['GET', 'POST'])
def changeBlockStatus():
    if request.method == 'POST':        

        prnno = request.form.get("prnno")  
        email = request.form.get("email")
        buttonText = request.form.get("buttonText")
           
        print(buttonText)
        sql1 = "UPDATE register SET blockstatus = %s WHERE prnno = %s AND email = %s;"
        val1 = (buttonText,prnno,email)
        cursor.execute(sql1,val1)
        con.commit()    
        
        return "success"
    
@app.route('/addCompany', methods=['GET', 'POST'])
def addCompany():
    if request.method == 'POST':
        print("GET")        

        cid = request.form.get("cid")
        cname = request.form.get("cname")  
        cbasic = request.form.get("cbasic")
        clocation = request.form.get("clocation") 
        cdesignation = request.form.get("cdesignation") 
        cpack = request.form.get("cpack") 
        cskill = request.form.get("cskill") 
        
        cursor.execute('SELECT * FROM companyregister WHERE cid = %s', (cid))
        count = cursor.rowcount
        if count > 0:
            return "fail"
        else:  
            sql1 = "INSERT INTO companyregister (cid, cname, cbasic, clocation, cdesignation, cpack, cskill) VALUES (%s, %s, %s, %s, %s, %s, %s);"
            val1 = (cid, cname, cbasic, clocation, cdesignation, cpack, cskill)
            cursor.execute(sql1, val1)
            con.commit()
            return "success"
        
@app.route('/getAllCompanies', methods=['GET', 'POST'])
def getAllCompanies():
    if request.method == 'POST':        

        username = request.form.get("username")  
        print("admin_getCall",username)
        
        cursor.execute('SELECT * FROM companyregister')
        row = cursor.fetchall() 
        
        jsonObj = json.dumps(row)      
        
        return jsonObj
    
@app.route('/editCompanyData', methods=['GET', 'POST'])
def editCompanyData():
    if request.method == 'POST':
        print("GET")        

        idofc = request.form.get("id")
        cid = request.form.get("cid")
        cname = request.form.get("cname")  
        cbasic = request.form.get("cbasic")
        clocation = request.form.get("clocation") 
        cdesignation = request.form.get("cdesignation") 
        cpack = request.form.get("cpack") 
        cskill = request.form.get("cskill") 
        
        sql1 = "UPDATE companyregister SET cid = %s,cname = %s,cbasic = %s,clocation = %s,cdesignation = %s,cpack = %s,cskill = %s WHERE id = %s;"
        val1 = (cid,cname,cbasic,clocation,cdesignation,cpack,cskill,idofc)
        cursor.execute(sql1,val1)
        con.commit()  
        return "success"
    
@app.route('/deleteCompanyData', methods=['GET', 'POST'])
def deleteCompanyData():
    if request.method == 'POST':        

        idoftpo = request.form.get("id")  
        cname = request.form.get("cname")
           
        sql11 = 'DELETE FROM companyregister WHERE id = %s AND cname = %s;'
        val11 = (idoftpo,cname)
        cursor.execute(sql11,val11)
        con.commit()  
        
        return "success"
    
@app.route('/tpologin', methods=['GET', 'POST'])
def tpologin():
    if request.method == 'POST':
        print("GET")        

        username = request.form.get("username")
        passw = request.form.get("password") 
        dept = request.form.get("dept")      
        print("INPUTS")        
        print("username",username)
        
        cursor.execute('SELECT * FROM tporegister WHERE username = %s AND password = %s AND dept = %s', (username, passw, dept))
        count = cursor.rowcount
        if count > 0:
            return "success"
        else:
            return "Fail"
        
@app.route('/getAllusers1', methods=['GET', 'POST'])
def getAllusers1():
    if request.method == 'POST':        

        username = request.form.get("username") 
        dept = request.form.get("dept")  
        print("admin_getCall",username)
        
        cursor.execute('SELECT * FROM register WHERE dept = %s AND status = %s',(dept,"Unverified"))
        row = cursor.fetchall() 
        
        jsonObj = json.dumps(row)       
        
        return jsonObj
    
@app.route('/getTpoProfile', methods=['GET', 'POST'])
def getTpoProfile():
    if request.method == 'POST':        

        username = request.form.get("username")  
        dept = request.form.get("dept")
           
        cursor.execute('SELECT * FROM tporegister WHERE username = %s AND dept = %s',(username,dept))
        row = cursor.fetchone()
        
        jsonObj = json.dumps(row)       
        
        return jsonObj
    
@app.route('/getStudProfile', methods=['GET', 'POST'])
def getStudProfile():
    if request.method == 'POST':        

        username = request.form.get("username")  
           
        cursor.execute('SELECT * FROM register WHERE prnno = %s',(username))
        row = cursor.fetchone()
        
        jsonObj = json.dumps(row)       
        
        return jsonObj
    
@app.route('/updateStudProfile', methods=['GET', 'POST'])
def updateStudProfile():
    if request.method == 'POST':
        print("GET")        

        idof = request.form.get("id")
        name = request.form.get("name")
        rollno = request.form.get("rollno")        
        prnno = request.form.get("prnno") 
        email = request.form.get("email")
        mobile = request.form.get("mobile")  
        dept = request.form.get("dept")     
        qualification = request.form.get("qualification")
        passingyear = request.form.get("passingyear")        
        skill = request.form.get("skill")
        language = request.form.get("language")    
        password = request.form.get("password")  
        print("INPUTS")        
        print("username",name)
        
        sql1 = "UPDATE register SET username = %s,rollno = %s,prnno = %s,email = %s,mobile = %s,dept = %s,qualification = %s,passingyear = %s,skill = %s,language = %s,password = %s,status = %s WHERE id = %s;"
        val1 = (name,rollno,prnno,email,mobile,dept,qualification,passingyear,skill,language,password,"Unverified",idof)
        cursor.execute(sql1,val1)
        con.commit() 
        return "success"
    
@app.route('/applyCompany', methods=['GET', 'POST'])
def applyCompany():
    if request.method == 'POST':        

        idoftpo = request.form.get("id")  
        cname = request.form.get("cname")
        prnno = request.form.get("prnno")
           
        cursor.execute('SELECT * FROM applycom WHERE cid = %s AND cname = %s AND studentprn = %s', (idoftpo,cname,prnno))
        count = cursor.rowcount
        if count > 0:
            return "fail"
        else:  
            sql1 = "INSERT INTO applycom (cid, cname, studentprn) VALUES (%s, %s, %s);"
            val1 = (idoftpo, cname, prnno)
            cursor.execute(sql1, val1)
            con.commit()
            return "success"
        
@app.route('/getEnrolledData', methods=['GET', 'POST'])
def getEnrolledData():
    if request.method == 'POST':
        print("GET")         
        
        cursor.execute('SELECT reg.username, reg.prnno, reg.email, reg.mobile, reg.dept, reg.qualification, reg.year3rd, compreg.cname, compreg.clocation, compreg.cdesignation, compreg.cpack FROM register reg JOIN applycom app ON reg.prnno = app.studentprn JOIN companyregister compreg ON compreg.id = app.cid AND compreg.cname = app.cname;')
        row = cursor.fetchall() 
        
        jsonObj = json.dumps(row) 
        
        return jsonObj
    
def create_pdf(dataframe):
    doc = SimpleDocTemplate("static/output.pdf", pagesize=letter, leftMargin=20, rightMargin=20, topMargin=20, bottomMargin=20)
    
    # Convert DataFrame to table data
    table_data = [list(dataframe.columns)] + dataframe.values.tolist()
    
    # Calculate column widths
    num_cols = len(dataframe.columns)
    col_width = (letter[0] - 20) / num_cols
    col_widths = [col_width] * num_cols

    # Create table
    table = Table(table_data, colWidths=col_widths, repeatRows=1)

    # Add style to table
    style = TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                        ('GRID', (0, 0), (-1, -1), 1, colors.black),
                        ('WORDWRAP', (0, 0), (-1, -1), True)])

    table.setStyle(style)
    
    # Build the PDF
    doc.build([table])
    
@app.route('/downloadData', methods=['GET', 'POST'])
def downloadData():
    if request.method == 'POST':
        print("GET")        

        data = request.form.get("data") 
        data_dict = json.loads(data)
        
        df = pd.DataFrame(data_dict)
        create_pdf(df[["Full name","PRN No.","Mobile","Qualification","Last year marks","Company name","Designation"]])
        return "success"
    
if __name__ == "__main__":
    app.run("0.0.0.0")
    
    


